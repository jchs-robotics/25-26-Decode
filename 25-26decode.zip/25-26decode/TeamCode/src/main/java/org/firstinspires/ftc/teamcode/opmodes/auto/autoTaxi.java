package org.firstinspires.ftc.teamcode.opmodes.auto;

import com.arcrobotics.ftclib.command.CommandOpMode;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.util.ElapsedTime;


import org.firstinspires.ftc.teamcode.components.subsystems.DriveSubsystem;
import org.firstinspires.ftc.teamcode.components.subsystems.IndexSubsystem;
import org.firstinspires.ftc.teamcode.components.subsystems.IntakeSubsystem;
import org.firstinspires.ftc.teamcode.components.subsystems.ShooterSubsystem;
import org.firstinspires.ftc.teamcode.components.subsystems.TurretSubsystem;

//@Config
@Autonomous(name = "Auto Taxi")
public class autoTaxi extends CommandOpMode {

    // initiate classes
    private IndexSubsystem indexSubsystem; // = new IndexSubsystem();
    private TurretSubsystem turretSubsystem; // = new TurretSubsystem();
    private IntakeSubsystem intakeSubsystem; // = new IntakeSubsystem();
    private DriveSubsystem driveSubsystem; // = new DriveSubsystem();
    private ShooterSubsystem shooterSubsystem; // = new ShooterSubsystem

    private final ElapsedTime timer = new ElapsedTime();


    @Override
    public void initialize() {


        //CommandScheduler.getInstance().reset();

        indexSubsystem = new IndexSubsystem(hardwareMap, "indexMotor");
        turretSubsystem = new TurretSubsystem(hardwareMap, "turretMotor");
        intakeSubsystem = new IntakeSubsystem(hardwareMap, "intakeMotor");
        driveSubsystem = new DriveSubsystem(hardwareMap, "frontleft", "backleft", "frontright", "backright", "imu");

        driveSubsystem.initializeDrive();

        waitForStart();
        timer.reset();
    }

    @Override
    public void run() {
        // Drive forward for the first 2 seconds
        if (timer.seconds() < 2) {
            driveSubsystem.Drive(-0.3, -0.3, -0.3, -0.3);
        } else {
            // Stop after 2 seconds
            driveSubsystem.Drive(0, 0, 0, 0);
        }
    }



}


