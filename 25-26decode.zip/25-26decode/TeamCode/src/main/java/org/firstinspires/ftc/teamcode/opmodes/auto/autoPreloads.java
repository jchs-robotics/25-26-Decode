package org.firstinspires.ftc.teamcode.opmodes.auto;

import com.arcrobotics.ftclib.command.CommandOpMode;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.util.ElapsedTime;


import org.firstinspires.ftc.teamcode.components.subsystems.DriveSubsystem;
import org.firstinspires.ftc.teamcode.components.subsystems.IndexSubsystem;
import org.firstinspires.ftc.teamcode.components.subsystems.IntakeSubsystem;
import org.firstinspires.ftc.teamcode.components.subsystems.ShooterSubsystem;
import org.firstinspires.ftc.teamcode.components.subsystems.TurretSubsystem;


//@Config
@Autonomous(name = "Auto Preloads")
public class autoPreloads extends CommandOpMode {

    // Subsystems
    private IndexSubsystem indexSubsystem;
    private TurretSubsystem turretSubsystem;
    private IntakeSubsystem intakeSubsystem;
    private DriveSubsystem driveSubsystem;
    private ShooterSubsystem shooterSubsystem;

    private final ElapsedTime timer = new ElapsedTime();

    @Override
    public void initialize() {
        indexSubsystem = new IndexSubsystem(hardwareMap, "indexMotor");
        turretSubsystem = new TurretSubsystem(hardwareMap, "turretMotor");
        intakeSubsystem = new IntakeSubsystem(hardwareMap, "intakeMotor");
        driveSubsystem = new DriveSubsystem(hardwareMap, "frontleft", "backleft", "frontright", "backright", "imu");
        shooterSubsystem = new ShooterSubsystem(hardwareMap, "shooterMotor");

        indexSubsystem.initializeIndex();
        turretSubsystem.initializeTurret();
        intakeSubsystem.initializeIntake();
        driveSubsystem.initializeDrive();
        shooterSubsystem.initializeShooter();


        waitForStart();
        timer.reset();
    }

    @Override
    public void run() {


        // --- Shooter runs for first 30 seconds ---
        if (timer.seconds() < 30) {
            shooterSubsystem.runShooter(-0.95);
        } else {
            shooterSubsystem.stopShooter();
        }

        // --- Index and Intake sequence ---
        if (timer.seconds() < 5) {
            // 0–5 sec: Shooter only
            indexSubsystem.stopIndex();
            intakeSubsystem.stopIntake();
            driveSubsystem.Drive(0, 0, 0, 0);

        } else if (timer.seconds() < 6.5) {
            // 5–6.5 sec: Run index
            indexSubsystem.runIndex(-1.0);
            intakeSubsystem.stopIntake();
            driveSubsystem.Drive(0, 0, 0, 0);

        } else if (timer.seconds() < 11.5) {
            // 6.5–11.5 sec: Stop index
            indexSubsystem.stopIndex();
            intakeSubsystem.stopIntake();
            driveSubsystem.Drive(0, 0, 0, 0);

        } else if (timer.seconds() < 14.5) {
            // 11.5–14.5 sec: Run index again
            indexSubsystem.runIndex(-1.0);
            intakeSubsystem.stopIntake();
            driveSubsystem.Drive(0, 0, 0, 0);

        } else if (timer.seconds() < 19.5) {
            // 14.5–19.5 sec: Stop index
            indexSubsystem.stopIndex();
            intakeSubsystem.stopIntake();
            driveSubsystem.Drive(0, 0, 0, 0);

        } else if (timer.seconds() < 21) {
            // 19.5–21 sec: Run intake
            intakeSubsystem.runIntake(-1.0);
            indexSubsystem.stopIndex();
            driveSubsystem.Drive(0, 0, 0, 0);

        } else if (timer.seconds() < 25) {
            // 21–25 sec: Run index again
            indexSubsystem.runIndex(-1.0);
            intakeSubsystem.stopIntake();
            driveSubsystem.Drive(0, 0, 0, 0);

        } else if (timer.seconds() < 27) {
            // 25–27 sec: Drive forward
            driveSubsystem.Drive(-0.3, -0.3, -0.3, -0.3);
            indexSubsystem.stopIndex();
            intakeSubsystem.stopIntake();

        } else {
            // 27–30 sec: Stop everything
            driveSubsystem.Drive(0, 0, 0, 0);
            indexSubsystem.stopIndex();
            intakeSubsystem.stopIntake();
        }

        // --- Telemetry ---
        telemetry.addData("Time", timer.seconds());
        telemetry.addData("Shooter", timer.seconds() < 30 ? "ON" : "OFF");
        telemetry.addData("Index",
                (timer.seconds() >= 5 && timer.seconds() < 6.5) || (timer.seconds() >= 11.5 && timer.seconds() < 14.5) || (timer.seconds() >= 21 && timer.seconds() < 25)
                        ? "ON" : "OFF");
        telemetry.addData("Intake", (timer.seconds() >= 19.5 && timer.seconds() < 21) ? "ON" : "OFF");
        telemetry.addData("Drive", (timer.seconds() >= 25 && timer.seconds() < 27) ? "DRIVING" : "STOPPED");
        telemetry.update();





    }
}



