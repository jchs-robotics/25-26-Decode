package org.firstinspires.ftc.teamcode.components;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;
//import com.qualcomm.robotcore.hardware.HardwareMap;

public class constants {
// SUBSYSTEM CONSTANTS
    // DRIVE
    public DcMotor FLDrive;
    public DcMotor BLDrive; // no Ei, not boy love
    public DcMotor FRDrive;
    public DcMotor BRDrive;


    //TURRET
    public DcMotor Turret;
    

    // INTAKE
    public DcMotor intake;

    // INDEX
    public DcMotor Index;

    // SHOOTER
    public DcMotor shooter;
    

    // ENCODERS
//    public double pivotEncoder = pivotLeft.getCurrentPosition();


// COMMAND CONSTANTS
    // DRIVE

    // TURRET

    // INDEX

    // INTAKE

    // SHOOTER


}